var canvas,
    ctx,
    env,
    isAlive = true,
    isFinished = false,
    player1,
    player2;

function restart(){

    if (!env){
        env = new Environment(15, 8, 64, 64);
    }

    if (isFinished) {
        env = new Environment(15, 8, 64, 64);
    } else {
        env.restart();
    }

    // --- NEW: SAFE SPAWN LOGIC ---
    
    // Player 1: Always starts Top-Left (0, 0)
    player1 = new Player(env, 0, 0); 

    // Player 2: We look for a safe spot near P1 (but not ON P1)
    // We try coordinates (2,0), (0,2), (2,2) which are nearby but not immediate death
    var candidates = [
        {c: 2, r: 0}, 
        {c: 0, r: 2}, 
        {c: 2, r: 2}, 
        {c: 3, r: 0},
        {c: 0, r: 3}
    ];

    var p2x = 0;
    var p2y = 0;
    var safeFound = false;

    // Loop through candidates to find one without a Hole or Wumpus
    for(var i = 0; i < candidates.length; i++){
        var testX = candidates[i].c * env.width;
        var testY = candidates[i].r * env.height;
        
        // Create temp player to check hazards
        var tempP = new Player(env, testX, testY);
        
        if (!env.hasAHole(tempP) && !env.hasAWumpus(tempP)) {
            p2x = testX;
            p2y = testY;
            safeFound = true;
            break; // Found a safe spot!
        }
    }

    // Fallback: If all nearby spots are dangerous, put P2 far away at the end
    if (!safeFound) {
        p2x = env.width * (env.i - 1);
        p2y = env.height * (env.j - 1);
    }

    // Spawn Player 2 at the safe spot
    player2 = new Player(env, p2x, p2y);

    // Make players global so they can interact
    window.player1 = player1; 
    window.player2 = player2;

    $("#modal-win").modal("hide");
    $("#modal-game-over").modal("hide");
    $('#btn-remove-walls').prop('checked', false);

    resources.stop("game-over");
    resources.stop("win");
    resources.play("theme", false);

    isAlive = true;
    isFinished = false;

    animate();
}

function resizeCanvas(){
    canvas.width = env.width * env.i;
    canvas.height = env.height * env.j;
}

function onKeydown(e) {
    animate();
};

function update(){
    
    var players = [player1, player2];

    players.forEach(function(p) {
        if (p.isDead) return;

        var currentKeys = (p === player1) ? window.keysP1 : window.keysP2;

        if (p.update(currentKeys)) {
            p.score -= 10;
        }

        var deadWumpus = p.kill(currentKeys);
        if (deadWumpus) {
            p.score += 1000;
            env.removeWumpus(deadWumpus);
        }

        var capturedGold = p.capture(currentKeys);
        if (capturedGold) {
            p.score += 500; // Halved Reward

            env.removeGold(capturedGold);
            resources.play("gold");

            if (env.golds.length == 0){
                isFinished = true;
            }
        }

        if(env.hasAHole(p) || env.hasAWumpus(p)){
            p.isDead = true; 
        }
    });

    // Game Over only if BOTH die
    if (player1.isDead && player2.isDead) {
        isAlive = false;
        displayGameOver();
    }

    $("#score").html("P1: " + player1.score + " | P2: " + player2.score);
    $("#arrow").html("P1: " + player1.arrow + " | P2: " + player2.arrow);
    $("#gold").html(env.golds.length);

    if(isFinished){
        displayCongratulations();
    }
}

function displayGameOver(){
    $("#modal-game-over").modal("show");
    resources.play("game-over", false);
    resources.stop("theme");
}

function displayCongratulations(){
    $("#modal-win").modal("show");
    resources.play("win", false);
    resources.stop("theme");
}

function draw(){
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (env) env.draw(ctx);

    if (player1 && !player1.isDead) player1.draw(ctx);
    if (player2 && !player2.isDead) player2.draw(ctx);
}

function animate(){
    update();
    draw();
}

function getURL(){
    var url = "{";
    url += "\"holes\":" + encodeToArray(env.holes) + ",";
    url += "\"golds\":" + encodeToArray(env.golds) + ",";
    url += "\"wumpus\":" + encodeToArray(env.wumpus) + "}";
    return "#" + btoa(url);
}

function encodeToArray(array){
    return JSON.stringify(array);
}

function getLink(){
    return window.location.href+getURL();
}

function loadEnvironment(hash){
    var link = atob(hash.replace('#', ''));
    var obj = $.parseJSON(link);
    env.holes = obj.holes;
    env.golds = obj.golds;
    env.wumpus = obj.wumpus;
    animate();
}

function getCurrentVolume(){
    return localStorage.getItem("wws-volume") || 0.1;
}

function changeVolumeTo(level){
    Howler.volume(level);
    localStorage.setItem("wws-volume", level);
}

function getCurrentLanguage(){
    return localStorage.getItem("wws-locale") || 'en_us';
}

function changeLanguageTo(locale){
    if (locale == "ar") {
        $("html[lang=en]").attr("dir", "rtl")
    } else {
        $("html[lang=en]").attr("dir", "ltr")
    }
    $.i18n().locale = locale;
    $('body').i18n();
    $('#select-language').selectpicker('refresh');
    localStorage.setItem("wws-locale", locale);
    draw();
}

$(function(){
    canvas = document.getElementById("canvas");
    ctx = canvas.getContext("2d");
    
    // NOTE: Keys are handled in keys.js now (window.keysP1 etc)

    $('select').selectpicker({ dropdownAlignRight: true });

    $.i18n.debug = true;
    $.i18n({ locale: getCurrentLanguage() });

    $.i18n().load( {
        en_us: 'i18n/en_us.json',
        pt_br: 'i18n/pt_br.json',
        ar: 'i18n/ar.json',
        fr: 'i18n/fr.json',
        tr_TR: 'i18n/tr_TR.json',
        es_mx: 'i18n/es_mx.json'
    }).done( function() {
        changeLanguageTo($.i18n().locale);
    });

    $('#select-language').selectpicker('val', $.i18n().locale);

    $("#select-language").change(function(event){
        event.preventDefault();
        changeLanguageTo($(this).val());
    });

    $('#btn-remove-walls').change(function() {
        env.removeWalls = this.checked;
        $(this).blur();
        animate();
    });

    $(".btn-restart").click(function(){
        restart();
    });

    $(".card-game").width(canvas.width);
    $(".card-game .card-content").height(canvas.height);

    $('#modal-share').on('shown.bs.modal', function () {
        $('#textarea-link').text(getLink());
    });

    changeVolumeTo(getCurrentVolume());

    $("#btn-volume").val(getCurrentVolume().toString());

    $("#btn-volume").change(function(event){
        event.preventDefault();
        changeVolumeTo($(this).val());
    });

    resources.load().then(() => {
        resources.play("theme", false);
        var hash = window.location.hash;
        if (hash) {
            loadEnvironment(hash);
        }
        restart();
        resizeCanvas();
        window.addEventListener("keydown", onKeydown, false);
        animate();
    })
});