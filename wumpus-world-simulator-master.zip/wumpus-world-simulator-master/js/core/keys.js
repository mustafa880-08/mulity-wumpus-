// Global key objects for two players
// We map different physical keys to the same logical actions (enter/space)
window.keysP1 = { up: false, down: false, left: false, right: false, enter: false, space: false };
window.keysP2 = { up: false, down: false, left: false, right: false, enter: false, space: false };

$(document).keydown(function(e) {
    
    // --- PLAYER 1 CONTROLS ---
    // Movement: Arrows
    if(e.which == 38) window.keysP1.up = true;
    if(e.which == 40) window.keysP1.down = true;
    if(e.which == 37) window.keysP1.left = true;
    if(e.which == 39) window.keysP1.right = true;
    
    // Actions: Enter (Pick Gold), Space (Shoot Arrow)
    if(e.which == 13) window.keysP1.enter = true;
    if(e.which == 32) window.keysP1.space = true;

    // --- PLAYER 2 CONTROLS ---
    // Movement: WASD
    if(e.key === 'w' || e.key === 'W') window.keysP2.up = true;
    if(e.key === 's' || e.key === 'S') window.keysP2.down = true;
    if(e.key === 'a' || e.key === 'A') window.keysP2.left = true;
    if(e.key === 'd' || e.key === 'D') window.keysP2.right = true;

    // Actions: E (Pick Gold), F (Shoot Arrow)
    // We map 'E' to the 'enter' property so the Player class understands it as "Pick Up"
    if(e.key === 'e' || e.key === 'E') window.keysP2.enter = true;
    // We map 'F' to the 'space' property so the Player class understands it as "Shoot"
    if(e.key === 'f' || e.key === 'F') window.keysP2.space = true;
});

// We need to reset keys on keyup so they don't get stuck "pressed"
$(document).keyup(function(e) {
    // --- PLAYER 1 RESET ---
    if(e.which == 38) window.keysP1.up = false;
    if(e.which == 40) window.keysP1.down = false;
    if(e.which == 37) window.keysP1.left = false;
    if(e.which == 39) window.keysP1.right = false;
    if(e.which == 13) window.keysP1.enter = false;
    if(e.which == 32) window.keysP1.space = false;

    // --- PLAYER 2 RESET ---
    if(e.key === 'w' || e.key === 'W') window.keysP2.up = false;
    if(e.key === 's' || e.key === 'S') window.keysP2.down = false;
    if(e.key === 'a' || e.key === 'A') window.keysP2.left = false;
    if(e.key === 'd' || e.key === 'D') window.keysP2.right = false;
    if(e.key === 'e' || e.key === 'E') window.keysP2.enter = false;
    if(e.key === 'f' || e.key === 'F') window.keysP2.space = false;
});